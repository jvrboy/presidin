# Nexus Forex Trading Bot

Nexus is a FastAPI-based forex trading bot API with durable SQLAlchemy persistence, authenticated trade operations, deterministic demo market data, risk controls, signal scanning, and a bundled dashboard prototype.

## What was repaired

The uploaded archive was a prototype rather than a runnable application: its modules were flat while imports expected a package tree, several imported strategy/data/scheduler modules were absent, authentication accepted unsafe defaults and optional query tokens, and the dashboard was disconnected from the API. This repository reorganizes the application into a tested package, removes hard-coded credentials, adds validation and durable account state, and makes demo behavior deterministic.

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set SECRET_KEY and ADMIN_PASSWORD in .env
uvicorn app.main:app --reload
```

Open `http://localhost:8000` for the dashboard or `http://localhost:8000/docs` for the OpenAPI documentation. Obtain a token with `POST /api/auth/login`, then send it as `Authorization: Bearer <token>` to protected endpoints.

## Production checklist

Set `ENVIRONMENT=production`, use a randomly generated `SECRET_KEY` of at least 32 characters, set a strong unique `ADMIN_PASSWORD`, use PostgreSQL rather than SQLite for multi-worker deployments, restrict `CORS_ORIGINS` to the real dashboard origin, terminate TLS at the hosting layer, and configure centralized logs and backups. Run the container with a non-root runtime policy in the target platform and keep `TRADING_MODE=demo` until a broker adapter, reconciliation loop, monitoring, and a paper-trading acceptance test are completed.

The current live-mode data adapter can read optional Yahoo Finance fallback data, but this repository does **not** claim to place real broker orders. A production broker integration must be added behind an explicit adapter interface with idempotency keys, order acknowledgments, reconciliation, circuit breakers, and operational alerts before live funds are used.

## API surface

| Endpoint | Auth | Purpose |
| --- | --- | --- |
| `GET /api/health` | No | Liveness and dependency status |
| `POST /api/auth/login` | No | Obtain a short-lived bearer token |
| `GET /api/status` | Yes | Current account snapshot |
| `GET /api/positions` | Yes | Open trades |
| `POST /api/trades` | Yes | Open a validated demo trade |
| `POST /api/trades/{id}/close` | Yes | Close a trade |
| `GET /api/signals` | Yes | Recent persisted signals |
| `POST /api/signals/scan` | Yes | Generate signals from current bars |
| `POST /api/engine/refresh` | Yes | Refresh prices and enforce SL/TP |
| `GET /api/performance` | Yes | Closed-trade performance summary |

## Tests

Run `pytest -q` (135 tests as of this revision). Coverage includes configuration safety, authentication, health, protected routes, trade validation, deterministic signal generation, the full indicator/backtest/optimization/portfolio/paper-execution/risk-management/regime/divergence/alerts/neural-model/microstructure/MARL suites, the mistake analyzer, top-down analysis, unified analysis engine, forward testing, the continuous learning loop (with an in-memory SQLite fixture), all 27 newly added strategies (parametrized backtest-without-error checks against demo data, plus assertions that no strategy uses a price field as its indicator), the 4 new persistent models, the from-scratch NumPy neural network + its scikit-learn adapter, the agentic accuracy-layer services (adaptive voter calibration, historical-analog accuracy, adversarial debate/critic agents, session intelligence, regime-shift/data-quality gating) plus an orchestrator-level integration test, and — newest — all 15 third-generation indicators (finite-value + determinism), the pattern-mining discovery engine (OOS-gate semantics, no-look-ahead outcome arrays, engine executability of mined configs), the mined-strategy catalog loader/endpoint, and the mining pipeline's group processor.

## Advanced indicators and analysis tools

Version 2.1 adds a registry-driven technical-analysis layer with more than 100 named indicators spanning trend, momentum, volatility, volume, market structure, Fibonacci, Ichimoku, statistical, candlestick, and risk families. The catalog is available at `GET /api/indicators/catalog`, while selected values can be calculated with `POST /api/indicators/calculate`.

The backend now also exposes authenticated tools for full market analysis, regime classification, support and resistance, volatility and tail-risk profiling, candlestick patterns, indicator confluence, and ATR-based trade-plan generation:

| Endpoint | Purpose |
| --- | --- |
| `GET /api/indicators/catalog` | List the registered indicator names and count |
| `POST /api/indicators/calculate` | Calculate selected indicators for a pair and bar window |
| `POST /api/tools/analyze` | Run the combined analysis suite |
| `POST /api/tools/regime` | Classify trending, ranging, and high-volatility conditions |
| `POST /api/tools/support-resistance` | Calculate pivot-based and range levels |
| `POST /api/tools/volatility` | Calculate realized volatility, VaR, expected shortfall, and ATR percentage |
| `POST /api/tools/patterns` | Detect common candlestick formations |
| `POST /api/tools/confluence` | Score multi-indicator directional agreement |
| `POST /api/tools/trade-plan` | Generate a demo-mode ATR-based plan with entry, stop, and target |

These tools are analytical outputs only. They do not authorize live brokerage execution, and all existing demo-mode safeguards remain in effect.

## Historical backtesting and strategy composer

The backend now supports persistent custom strategies built from indicator-confluence rules. A strategy contains entry rules, optional exit rules, `AND`/`OR` logic, direction selection, ATR stop and target multiples, risk per trade, and an optional maximum holding period measured in completed OHLC bars. Every rule is validated against the registered indicator catalog before it is saved.

Historical evaluation uses `POST /api/strategies/{strategy_id}/backtest`. The default source is `yahoo`, which loads actual historical forex bars through Yahoo Finance. The `demo` source is explicit and exists only for automated tests and local API demonstrations; production evaluations should use a real historical source and record the returned data source with every run.

| Endpoint | Purpose |
| --- | --- |
| `POST /api/strategies` | Create and persist a custom strategy |
| `GET /api/strategies` | List strategies owned by the authenticated user |
| `GET /api/strategies/{id}` | Retrieve one saved strategy and its rule configuration |
| `POST /api/strategies/{id}/backtest` | Run and persist a historical evaluation |
| `GET /api/backtests` | Review the authenticated user’s previous runs |

The backtester avoids look-ahead entries by evaluating rules on the completed bar and entering at the next bar’s open. It supports configurable commission and slippage, ATR-based stops and targets, risk-sized positions, exit rules, time exits, forced end-of-data exits, equity curves, trade details, win rate, profit factor, expectancy, maximum drawdown, Sharpe, Sortino, VaR-related data through the indicator layer, and return statistics. Backtest results are research outputs and do not guarantee future performance.

## Optimization and portfolio research

The platform now includes automated parameter sweeps and walk-forward optimization. A sweep accepts dotted configuration paths such as `entry_rules.0.value` or `atr_stop_multiple`, evaluates every bounded combination, and ranks results by a selected objective. Walk-forward evaluation divides the historical sample into rolling in-sample and out-of-sample windows, selects parameters only from the in-sample segment, and evaluates those parameters on the subsequent out-of-sample segment.

| Endpoint | Purpose |
| --- | --- |
| `POST /api/strategies/{id}/parameter-sweep` | Evaluate a bounded parameter grid and return ranked candidates |
| `POST /api/strategies/{id}/walk-forward` | Optimize on rolling training windows and evaluate on untouched test windows |
| `POST /api/strategies/{id}/portfolio-backtest` | Run one strategy across multiple pairs with explicit portfolio weights |
| `POST /api/tools/correlation` | Calculate Pearson, Spearman, or Kendall return correlations across pairs |

Portfolio backtesting allocates starting capital by normalized pair weights, runs each pair independently, aggregates equity curves, and reports portfolio return, drawdown, Sharpe ratio, total trades, and pair-level results. Correlation analysis uses historical close-to-close returns and returns the full matrix plus pairwise summary statistics. These features are designed for research and validation; they do not imply that an optimized strategy will perform similarly in future markets.

## Paper execution and ML signal filtering

The backend now includes an execution abstraction that is hard-gated to `EXECUTION_MODE=paper`. The local paper broker provides deterministic quote and fill simulation, while the OANDA adapter is restricted to the OANDA practice environment. An optional MetaTrader demo adapter is available when the native package and a configured demo terminal are present; real-money execution is intentionally unsupported by this release.

| Endpoint | Purpose |
| --- | --- |
| `POST /api/paper/quote` | Retrieve a current bid/ask quote through the configured paper broker |
| `POST /api/paper/orders` | Submit a paper market order and persist the execution audit record |
| `POST /api/paper/orders/{id}/close` | Close a local paper order where supported |
| `GET /api/paper/orders` | Review persisted paper-order records |
| `POST /api/meta-models/train` | Train a time-ordered Random Forest meta-label model on historical indicator features |
| `GET /api/meta-models` | List the authenticated user’s trained models and feature rankings |
| `POST /api/meta-models/filter` | Score a current candidate using predicted success probability and an acceptance threshold |

Meta-labeling uses forward-return labels, an 80/20 chronological train/test split, balanced Random Forest classification, probability-based acceptance, and feature-importance ranking. The model is a secondary filter for base indicator signals, not a replacement for risk controls or validation. Model artifacts are stored with ownership metadata and should be retrained when the market regime, feature set, or data source changes.

Set `BROKER_PROVIDER=paper` for local validation. OANDA practice requires `BROKER_PROVIDER=oanda_practice`, a practice account ID, a practice API token, and the practice URL. Credentials must be provided through environment variables and must never be committed to the repository.

## Advanced risk management

The paper-execution layer now applies centralized risk controls before submitting orders. When `RISK_SIZING_MODE=percent_risk`, omitted order units are calculated from account equity and stop distance so the configured percentage of equity is placed at risk. Every order is also checked against the daily drawdown limit, maximum open positions, total exposure cap, maximum order size, and minimum protective-stop distance.

Trailing stops can be updated using ATR distance, percentage distance, or both. The stop is monotonic: it can tighten in the direction of profit but cannot widen an existing protective stop. Daily drawdown status and exposure are available through the risk APIs.

| Endpoint | Purpose |
| --- | --- |
| `GET /api/risk/status` | View equity, daily drawdown, open exposure, and position-limit status |
| `POST /api/risk/size` | Preview a risk decision and dynamically sized broker units |
| `POST /api/paper/orders/{id}/trail` | Tighten an existing paper order’s stop using ATR or percentage distance |
| `POST /api/paper/orders` | Submit a risk-checked paper order; units may be omitted for dynamic sizing |

The controls are configuration-driven through `RISK_PERCENT_PER_TRADE`, `MAX_DAILY_DRAWDOWN_PCT`, `MAX_TOTAL_EXPOSURE`, `MAX_OPEN_POSITIONS`, `MAX_UNITS_PER_ORDER`, `TRAILING_STOP_ATR_MULTIPLE`, `TRAILING_STOP_PERCENT`, and `MINIMUM_STOP_DISTANCE_PIPS`. They are safeguards for paper validation and should be combined with broker reconciliation, monitoring, and independent operational review before any higher-risk deployment.

## Multi-timeframe regimes and divergence systems

The research layer now supports cross-timeframe regime analysis using a Gaussian hidden Markov model. It derives returns, rolling volatility, trend, and range features from each historical timeframe, trains a three-state model by default, labels states as bearish trend, range, or bullish trend, and combines posterior probabilities into a weighted multi-timeframe consensus. The model is fitted per request from the selected historical source and is not used to bypass paper-execution risk controls.

The divergence subsystem detects regular and hidden divergence between price pivots and RSI, MACD, stochastic, and OBV oscillators. It returns pivot details, oscillator comparisons, direction, strength, counts, bias, and a multi-oscillator confluence score. Divergence strategy evaluation converts the confluence score into `BUY`, `SELL`, or `WAIT` with a confidence value.

| Endpoint | Purpose |
| --- | --- |
| `POST /api/tools/multi-timeframe-regime` | Train HMM regimes for multiple timeframes and return weighted consensus |
| `POST /api/tools/divergence-system` | Detect regular and hidden divergences across selected oscillators |
| `POST /api/tools/divergence-strategy` | Evaluate the multi-oscillator divergence strategy signal |
| `POST /api/tools/mtf-confluence` | Combine multi-timeframe HMM regime consensus with divergence strategy outputs |
| `GET /api/strategies/builtin` | Includes RSI regular-divergence and MACD hidden-divergence templates |

New catalog indicators include regular and hidden RSI/MACD divergence outputs, allowing them to participate in saved strategy rules and backtest configuration. The divergence implementation is intentionally conservative: it requires confirmed pivot relationships within the lookback window and reports `WAIT` when confluence is insufficient.

## Automated alerts, neural models, and control-room dashboard

The bot now includes an automated alert monitor that evaluates enabled divergence and regime-shift rules on the configured paper-mode interval. Rules are persisted per user and deduplicated by event signature before delivery. Telegram uses the Bot API `sendMessage` method, while Discord uses an incoming webhook payload with embeds. Credentials are environment-only and never stored in the database.

| Capability | Endpoint or configuration |
| --- | --- |
| Alert rules | `POST /api/alerts/rules`, `GET /api/alerts/rules`, `POST /api/alerts/rules/{id}/evaluate` |
| Test notifications | `POST /api/alerts/test` |
| Delivery audit | `GET /api/alerts/deliveries` |
| Telegram | `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, optional `TELEGRAM_WEBHOOK_SECRET` |
| Discord | `DISCORD_WEBHOOK_URL` |
| Polling | `ALERT_POLL_SECONDS` controls the background evaluation interval |
| Neural models | `POST /api/neural-models/train`, `GET /api/neural-models`, `POST /api/neural-models/filter` |
| Dashboard data | `GET /api/dashboard/overview`, `GET /api/market/ohlc` |

The neural signal filter uses a time-ordered multilayer perceptron over returns, volatility, trend, range, and volume features. It stores model artifacts and permutation feature-importance rankings, then exposes a probability threshold for accepting or rejecting a signal. It is a research filter and does not authorize live-money execution.

The existing root dashboard now includes a live-intelligence panel for authenticated users. It visualizes price and divergence lines, HMM regime cards for multiple timeframes, alert-delivery history, performance, and neural feature rankings. The default data refresh uses the explicit deterministic demo source; replace it with authenticated historical or broker-backed data for operational validation.

> Telegram and Discord delivery require user-supplied credentials. Without configured credentials, alert evaluation remains available and records failed delivery attempts rather than silently claiming success.

## Verified external delivery references

[1]: https://core.telegram.org/bots/api "Telegram Bot API"
[2]: https://docs.discord.com/developers/resources/webhook "Discord Webhook Resource"

The outbound delivery design follows the official API behavior documented by Telegram and Discord.[1] [2]

## Neural evaluation and mock-broker validation

The repository now includes a full neural-trend-filter evaluation entrypoint at `scripts/run_neural_evaluation.py`, a deterministic mock-broker replay at `scripts/run_mock_validation.py`, and a specialist-agent ensemble endpoint. The mock replay uses explicit demo data and models bid/ask spread, sequential ticks, no-lookahead feature updates, probability filtering, and paper-only actions.

| Tool | Endpoint or artifact |
| --- | --- |
| Neural trend backtest | `POST /api/neural/backtest` |
| Mock broker validation | `POST /api/mock-feed/validate` |
| Specialist and sub-agent ensemble | `POST /api/agents/ensemble` |
| Four-model neural ensemble | `POST /api/neural-ensemble/analyze` |
| Offline mock report | `reports/mock_broker_neural_validation.md` |

The specialist ensemble combines deterministic trend, momentum, volatility, regime, divergence, liquidity, risk, and breakout sub-agents. The breakout template is explicitly long-only because its available entry indicators only confirm upside conditions. The neural ensemble combines an MLP, random forest, gradient boosting classifier, and probabilistic linear SGD model, returning model-level probabilities, accuracy, agreement, feature values, and a composite action.

The requested real-data historical backtest was attempted with Yahoo Finance for EURUSD daily bars from 2019-01-01 through 2025-12-31, but the provider returned no data in this environment. Stooq returned a browser-verification page. The ECB data API was reachable, but it provides daily reference values rather than OHLC bars and therefore was not incorrectly converted into synthetic high/low data. The full OHLC result must be run after supplying a trusted broker, Dukascopy, HistData, MetaTrader, or other OHLC CSV export. See `docs/backtest_data_findings.md` for the source audit.

## MARL and market microstructure tools

The backend now includes a paper-only multi-agent decision layer and market-microstructure analytics. The MARL layer uses bounded tabular Q-agents for depth, trend, timing, and risk. Each agent proposes an entry action, size multiplier, delay, confidence, and rationale; the negotiator returns a weighted decision with explicit state, proposals, negotiated units, and a paper-only flag. Reward updates are exposed for controlled research experiments and do not place orders.

| Tool | Endpoint |
| --- | --- |
| Order-book depth | `POST /api/tools/order-book` |
| Volume profile and market profile | `POST /api/tools/microstructure` |
| Order-flow delta | `POST /api/tools/microstructure` |
| Liquidity map | `POST /api/tools/microstructure` |
| Execution quality | Included in `/api/tools/order-book` |
| MARL negotiation | `POST /api/marl/negotiate` |
| MARL reward update | `POST /api/marl/reward` |

The order-book analytics calculate spread, spread basis points, microprice, bid/ask depth, depth imbalance, depth slopes, and pressure. Volume profile returns point of control, value area, high-volume nodes, and low-volume nodes. Order flow estimates signed candle-volume delta, cumulative delta, buying/selling volume, and imbalance. Market profile returns TPO-style distribution and value-area levels. Liquidity analysis locates nearby swing liquidity and sweep risk, while execution-quality analysis estimates spread cost, microprice deviation, depth coverage, and a `GOOD`/`CAUTION` quality classification.

The current MARL implementation is intentionally auditable and bounded. It is a research decision-support layer, not an autonomous live-money reinforcement-learning trader. Any negotiated size must still pass the existing paper-execution risk manager, dynamic sizing, drawdown, exposure, and trailing-stop controls.

## Deriv market data, unified analysis engine, and top-down/SMT tooling

The backend now integrates [Deriv's public WebSocket API](https://developers.deriv.com/) (`wss://ws.derivws.com/websockets/v3`, `app_id=1089`, no account/API key required) as a first-class historical and real-time data source. **As of the 2026-08 expansion this covers 25 tracked instruments** (up from an original 16) -- see "Confluence governance, expanded instrument coverage, and the real-data training pipeline" below for the full current list and the live-verification audit trail. `Settings.all_symbols` is the single source of truth every endpoint validates pairs/symbols against — it is the de-duplicated union of the 6 legacy `supported_pairs` and the (now 25) `deriv_symbols`, so Deriv-only instruments are recognized everywhere pair validation occurs (trades, signals, strategies, analysis, forward tests).

| Endpoint | Purpose |
| --- | --- |
| `GET /api/deriv/symbols` | List all tracked Deriv symbols and their correlated-pair map |
| `GET /api/deriv/ohlc` | Fetch live/historical OHLC bars directly from Deriv for one symbol |
| `HistoricalDataProvider.load(..., source="deriv")` | Deriv-backed historical data for backtests/optimization/forward-tests, with automatic clamping to Deriv's ~350-day retention window |

**Unified per-symbol analysis engine** (`app/services/unified_analysis.py`) combines every existing analysis tool — regime classification, support & resistance (classic + psychological + dynamic zones), volatility profile, candlestick patterns, indicator confluence, ATR trade plan, market structure, Wyckoff phase, harmonic/Fibonacci patterns, supply & demand (order blocks + fair value gaps + liquidity zones), 7-oscillator divergence with multi-timeframe confluence, and SMT correlation divergence — into a single result object plus a plain-English commentary paragraph explaining *why* the engine reached its conclusion.

**Top-down (multi-timeframe) analysis** (`app/services/top_down_analysis.py`) computes an independent bias per timeframe (ordered highest-to-lowest, e.g. `1d → 4h → 1h`), then only recommends `BUY`/`SELL` when the *entire* cascade agrees — filtering out low-timeframe noise that contradicts the bigger picture.

**Smart Money Tool (SMT) correlation divergence** (`app/services/smt_divergence.py`) detects when two historically correlated/anti-correlated instruments (e.g. `XAUUSD`/`XAGUSD`, `EURUSD`/`USDCAD`, or correlated synthetic-index pairs) diverge from their expected relationship at swing pivots — a classic institutional-footprint signal.

| Endpoint | Purpose |
| --- | --- |
| `POST /api/analysis/unified` | Run the full unified analysis stack for one symbol/timeframe; persists an `AnalysisSnapshot` |
| `POST /api/analysis/unified-multi-timeframe` | Run unified analysis across multiple timeframes plus a consensus read |
| `POST /api/analysis/top-down` | Cascading multi-timeframe bias (only agrees when every timeframe aligns) |
| `POST /api/analysis/scan-all` | Run unified analysis across all (or a requested subset of) the tracked Deriv symbols in one call |
| `GET /api/analysis/snapshots` | Review persisted `AnalysisSnapshot` history, filterable by symbol |
| `POST /api/tools/smt-divergence` | SMT correlation-divergence check for one symbol pair |
| `POST /api/tools/smt-scan` | Scan all pre-defined correlated pairs for SMT divergence in one call |

A background scheduler (`symbol_scanner()` in `app/main.py`, alongside the existing `alert_monitor()` task) runs every 15 minutes, evaluates the unified analysis engine for every one of the tracked Deriv symbols, and persists each result as an `AnalysisSnapshot` row — giving a continuously updated, queryable analysis history without requiring a manual scan call.

## Forward testing (out-of-sample validation, distinct from walk-forward)

`app/services/forward_test.py` implements strict out-of-sample validation, deliberately distinct from the existing `OptimizationEngine.walk_forward` (which repeatedly re-optimizes parameters on rolling windows). A forward test takes an **already-tuned, unmodified** strategy configuration, splits the historical data chronologically into a front "in-sample" slice and a strictly later, non-overlapping "forward" slice, runs the identical config on both via `BacktestEngine.run()`, and compares seven headline metrics (net profit, total return %, win rate %, profit factor, Sharpe, Sortino, expectancy, max drawdown %) with a 35% degradation tolerance. The result is a `PASS` / `WARN` / `FAIL` / `INCONCLUSIVE` verdict — genuine evidence a strategy's edge isn't simply overfit to its tuning window, without changing a single parameter between runs.

| Endpoint | Purpose |
| --- | --- |
| `POST /api/strategies/{strategy_id}/forward-test` | Run a saved strategy's config through the in-sample/forward split and return the verdict |

Systematic sweep reports covering all 16 symbols, 50 strategies, and multiple timeframes are generated by `scripts/run_backtest_report.py` (2,400 runs: 16 symbols × 50 strategies × 3 timeframes) and `scripts/run_forward_test_report.py` (800 runs: 16 symbols × 50 strategies on 1h); see `reports/backtest_report_summary.md` and `reports/forward_test_report_summary.md` for the latest results (raw per-run data in the corresponding `.jsonl`/`.csv` files). Both completed with **zero errors** against the demo data source.

**The two reports tell a cautionary story together, exactly the story forward testing exists to catch.** The backtest sweep's top 3 strategies by average return (`rsi_regular_divergence_v2` 22.5%, `psar_flip_trend` 22.4%, `hull_ma_momentum` 19.5%) each show a **0% forward-test pass rate — every single forward-test run for these three strategies came back FAIL**, meaning their in-sample profitability collapses on the immediately following out-of-sample slice. Across the full 800-run forward-test sweep, only 17% of runs `PASS`ed, 67.4% `FAIL`ed, 14.4% were `INCONCLUSIVE` (forward slice generated no trades), and 1.2% `WARN`ed. The strategies with the *highest* forward-test pass rates (`dpo_cycle_reversal` 81.2%, `fisher_transform_extreme` 75%) were mid-table by raw backtest return, not top performers — reinforcing that raw historical return alone is not evidence of a durable edge, and that both reports must be read together before trusting a strategy's signals. `EURUSD` had the best forward-test pass rate among symbols (46%); the synthetic Drift Switch indices had the worst (2–4%).

## Continuous per-signal learning loop and mistake analysis

`app/services/learning_loop.py` closes the loop between signal generation and strategy improvement, entirely within paper/demo execution (no live broker orders are ever placed — this tracks the outcome of signals the user may act on manually):

1. **`open_outcome()`** — records a `PENDING` `SignalOutcome` row at signal time with market-context snapshot (JSON).
2. **`resolve_outcome()`** — once the trade's real-world outcome is known, computes `WIN`/`LOSS`/`BREAKEVEN` from the pip distance between entry and exit (0.5-pip tolerance). On a `LOSS`, it automatically runs `app/services/mistake_analyzer.py`'s rule-based classifier (`analyze_trade_mistake()` — 9 mistake categories: e.g. `counter_trend_entry`, `stop_too_tight`, `chased_extended_move`) and persists a `MistakeLog` row with the classified category, confidence, and a suggested adjustment.
3. **`run_retraining_cycle()`** — an auditable retraining pass: splits resolved outcomes chronologically into older/newer halves to compute `win_rate_before`/`win_rate_after`, aggregates every `MistakeLog` entry via `summarize_mistakes()` (ranked by frequency), and persists the full audit trail as a `TrainingRun` row (`lessons_json`).

| Endpoint | Purpose |
| --- | --- |
| `POST /api/signals/{signal_id}/outcome` | Open a `PENDING` outcome record for a generated signal |
| `POST /api/signal-outcomes/{outcome_id}/resolve` | Resolve an outcome with the real exit price; triggers mistake classification on a loss |
| `GET /api/signal-outcomes/pending` | List outcomes still awaiting resolution |
| `POST /api/training/run` | Run a retraining cycle (manual, scheduled, or outcome-threshold triggered) |
| `GET /api/training/runs` | Review the full audit history of retraining cycles and their lessons |
| `GET /api/mistakes/summary` | Aggregate and rank mistake categories across all resolved losses |

This is explicitly a **signal-quality improvement loop, not an auto-trading system** — `TRADING_MODE`/`EXECUTION_MODE` remain hard-gated to demo/paper throughout, matching every other execution path in this repository. The rigor here exists because the user manually acts on these signals with real capital, so signal quality and the honesty of the training audit trail both matter.

## From-scratch NumPy neural network (from the uploaded `advanced_brain` archive)

`app/services/scratch_neural_network.py` is a from-scratch NumPy implementation of a configurable feed-forward neural network (arbitrary layer sizes; relu/sigmoid/tanh/linear activations; mini-batch gradient descent with MSE or binary cross-entropy loss; JSON/NPZ save-load), adapted from the user-uploaded `advanced_brain.zip` archive's `networks/core.py`. It is wrapped by `ScratchNeuralNetworkClassifier`, a thin scikit-learn-compatible adapter (`fit`/`predict`/`predict_proba`) registered in the neural model zoo (`app/services/neural_model_zoo.py`) as architecture `"scratch_numpy_net"`, trainable and evaluable identically to the zoo's existing sklearn architectures (`mlp_shallow`, `mlp_deep`, `mlp_tanh`, `extra_trees`, `hist_gradient_boosting`, `logistic_baseline`) and included in the same consensus-voting logic. Request it via `POST /api/neural-models/train` (or the model-zoo training endpoint) with `"architectures": ["scratch_numpy_net", ...]`.

The two image attachments the user uploaded alongside `advanced_brain.zip` could not be read/decoded in this environment; the user was informed and all `advanced_brain.zip`-derived work above proceeded from the zip's code contents only.

## Divergence, top-down, and strategy library expansion

The strategy library has grown from the original 23 to 50 builtin strategies (`GET /api/strategies/builtin`), spanning trend-following, mean-reversion, breakout, multi-indicator confluence, Ichimoku, Wyckoff, harmonic, order-block, fair-value-gap, and — new this round — supply & demand, support & resistance, and multiple divergence-based templates. The divergence oscillator set now covers 7 oscillators (`RSI_14`, `MACD`, `STOCH_14`, `OBV`, `CCI_20`, `MFI_14`, `WILLR_14`); every backtest rule enforces that a price field (`OPEN`/`HIGH`/`LOW`/`CLOSE`) may only appear as a rule's comparison *value*, never as the *indicator* being evaluated.

## Persistent analysis and learning-loop data models

Four new SQLAlchemy models back the features above, all persisted to the same durable SQLite/PostgreSQL store as every other table in this application (no in-memory or file-based state):

| Model | Purpose |
| --- | --- |
| `AnalysisSnapshot` | One row per unified-analysis run (manual, scan-all, or background scanner), with bias/confidence/commentary and the full JSON result |
| `SignalOutcome` | One row per tracked signal, from `PENDING` through `WIN`/`LOSS`/`BREAKEVEN` resolution, with pnl in pips and mistake category |
| `MistakeLog` | One row per classified losing trade, linked to its `SignalOutcome`, with category/confidence/suggested adjustment |
| `TrainingRun` | One row per retraining cycle, with before/after win rate and the aggregated mistake-category lessons for that cycle |

## Confluence governance, expanded instrument coverage, and the real-data training pipeline

This section documents the 2026-08 revision that expanded instrument/timeframe coverage to the project owner's full requested list and rebuilt signal generation around a strict "every tool is a vote, nothing is a unilateral rule" architecture, driven by two explicit requirements: (1) never let any single tool/agent/model decide a signal outright, and (2) eliminate guessed stop-loss/take-profit distances in favor of numbers measured from real historical trade outcomes.

**Tracked instruments (25, up from 16):** `XAUUSD`, `EURUSD`, `GBPUSD`, `AUDUSD`, `XAGUSD`, `USDJPY`, `AUDCAD`, `USDCAD`, `USDCHF`, `US500` (Deriv `OTC_SPC`), `US30` (Deriv `OTC_DJI`), `DRIFT_SWITCH_10/20/30`, and both Volatility Index families -- the "1s" `VOLATILITY_5/10/30/50/75/90` and the standard `VOL10/25/50/75/100` (Deriv `R_10/25/50/75/100`). Every code was live-verified against Deriv's public API one-by-one before being added; the full probe transcript, including the failed candidate codes tried first (`US_500`, `US_30`, `OTC_AS30`), is in `docs/deriv_symbol_verification.md`.

**Tracked timeframes (10, always all of them, never a subset):** `1m, 5m, 15m, 30m, 1h, 2h, 4h, 8h, 1d, 1w` -- `Settings.all_timeframes`. Deriv's API has no native weekly granularity, so `1w` is produced by fetching `1d` bars and resampling to calendar weeks in `HistoricalDataProvider._resample()`.

**Honest data-window disclosure:** Deriv's public API only retains roughly the last ~350 days of history for any symbol (confirmed empirically, not documented by Deriv) -- `MAX_HISTORICAL_LOOKBACK_DAYS = 350` in `app/services/deriv_client.py`. "Maximum available historical data" for these instruments realistically means ~1 year, not multiple years. This is a platform limit, disclosed rather than silently worked around (rule R8 below).

### The confluence rule set (`rules/confluence_rules.json`, human-readable companion `docs/CONFLUENCE_RULES.md`)

Nine machine-readable rules (R1-R9) that every current and future tool/agent in this repository must follow, each naming the exact module/function that enforces it:

| Rule | Statement |
| --- | --- |
| R1 | Confluence, not authority -- no single tool/agent/model may declare a final trading decision; every component returns a (direction, confidence, weight, reason) vote |
| R2 | All 10 timeframes, always -- never a subset, for every symbol, every analysis |
| R3 | Training and simulated signals use real data only (`source="deriv"`), never demo/synthetic data |
| R4 | No stop-loss/take-profit guessing -- `tp_sl_calibration.calibrate_stop_target()` is the only sanctioned place SL/TP is computed, preferring measured MAE/MFE over an ATR-multiple fallback |
| R5 | Every signal is persisted and the next signal for that symbol looks up how prior signals performed |
| R6 | Every signal always carries entry, stop-loss, take-profit, and win-rate fields (win-rate is null+reason when not yet measurable, never fabricated) |
| R7 | Paper/demo execution only -- this system generates signals for a human to place manually; it never executes live trades |
| R8 | Honest data-window disclosure -- the ~350-day Deriv retention limit is surfaced, not hidden |
| R9 | No silent failures in batch runs -- every sweep records OK/ERROR per unit of work |

### Confluence orchestrator -- the "everything is a vote" engine

`app/services/confluence_orchestrator.run_symbol(symbol, primary_timeframe)` is the only place in the codebase allowed to turn a collection of tool/agent outputs into one emitted signal. For every one of the 10 required timeframes it runs `confluence_score`, `market_regime`, `market_structure`, `supply_demand_zones`, `divergence_strategy`, the specialist ensemble, and the unified-bias engine, each wrapped as a `Vote(direction, confidence, weight, reason)` -- never a final answer. Votes are weighted-averaged per timeframe, then averaged again across all OK timeframes; a symbol+strategy's recent measured win rate (from the signal ledger) nudges the aggregate confidence up or down. Stop-loss/take-profit come exclusively from `tp_sl_calibration.calibrate_stop_target()`. The resulting signal is persisted to the ledger before being returned, and always carries `entry`, `stop_loss`, `take_profit`, and `win_rate` (or an explicit `win_rate_reason` when no measured rate exists yet).

| Endpoint | Purpose |
| --- | --- |
| `POST /api/confluence/signal` | Generate one confluence signal for a symbol across all 10 timeframes |
| `POST /api/confluence/scan-all` | Run the confluence signal generator across all (or a requested subset of) tracked symbols |

### TP/SL calibration -- eliminating guessed stops (`app/services/tp_sl_calibration.py`)

Two tiers, always in this preference order:
1. **`measured_mae_mfe`** -- once a symbol+timeframe has accumulated >=20 real winning-trade samples from the training pipeline, the stop distance is set from the measured 90th-percentile maximum-adverse-excursion of those winners, and the target from their measured maximum-favorable-excursion -- a number backed by what actually happened, not a guess.
2. **`atr_fallback`** -- until that calibration exists, stop/target fall back to a multiple of the current bar's ATR, explicitly labeled `calibration_tier="atr_fallback"` so callers always know whether a number is measured or provisional.

`app/services/backtester.py`'s `BacktestEngine` now tracks each trade's `max_adverse_excursion`/`max_favorable_excursion` bar-by-bar while a position is open, which is what feeds tier 1.

### Signal ledger -- persist every signal, learn from prior performance (`app/services/signal_ledger.py`)

Every signal the confluence orchestrator produces is appended to a per-symbol JSONL ledger (`data/signal_ledger/{SYMBOL}.jsonl`) with its full vote breakdown, direction, entry/stop/target, and confidence. `recent_performance(symbol, strategy)` looks up how prior resolved signals for that exact symbol+strategy pairing performed and returns a measured win rate (or an explicit `"reason": "no_resolved_signals_yet"` when there isn't one) -- this is what the next signal generation call for that instrument uses to improve, per rule R5.

### Real-data training pipeline (`scripts/run_real_data_training_pipeline.py`)

Sweeps every tracked symbol (25) x every required timeframe (10) x every strategy this repo knows (62 `builtin_strategies()` + 4 `ADVANCED_BUILTIN_STRATEGIES` = 66 as of revision 4) = 33,000 (backtest, forward-test) runs, using **only** `source="deriv"` real historical data -- never demo/synthetic (rule R3). Jobs are grouped by (symbol, timeframe) so real Deriv history is fetched exactly once per group (250 fetches total) and reused across all 66 strategies for that group, since `BacktestEngine`'s per-bar indicator recompute cost grows roughly with the square of bar count (measured: one strategy went from ~2.6s at 120 bars to ~84s at 1001 bars on this sandbox's 2 vCPUs) -- `--bar-cap` (default 150) bounds that compute cost per run without reducing the real ~340-day lookback window each group still fetches from Deriv. Every winning trade's measured MAE/MFE is pooled per group; once a group crosses 20 pooled winning trades, a `data/calibration/{SYMBOL}_{timeframe}.json` file is written, unlocking the `measured_mae_mfe` tier for that exact symbol+timeframe. The run is checkpointed at (symbol, timeframe) granularity in `reports/training_pipeline_progress.json`, so it can be safely stopped and resumed, and every result -- OK or ERROR, at both the group and strategy level -- is appended to `reports/training_pipeline_raw.jsonl` (rule R9). See `reports/training_pipeline_summary.md` for the latest leaderboard and calibration coverage once a run completes.

```bash
source /home/user/nexus_venv/bin/activate
python3 scripts/run_real_data_training_pipeline.py             # full 250-group sweep, resumable
python3 scripts/run_real_data_training_pipeline.py --symbols XAUUSD,EURUSD --timeframes 1h,4h --max-groups 5
```

## Agentic accuracy layer (2026-08 revision 2)

Version 2.3 adds five new intelligence services that raise signal accuracy by making the confluence stack **self-measuring** and **adversarially reviewed**, all under the same R1-R9 governance (every output is advisory; execution stays hard-gated to paper/demo):

| Service | Module | What it adds |
| --- | --- | --- |
| Adaptive voter-weight calibration | `app/services/voter_calibration.py` | Replaces the static per-voter weights with reliability-adjusted weights learned from this exact symbol+strategy's resolved ledger history. Each voter accumulates a Beta-Bernoulli track record ("did my vote agree with what actually happened"); posterior-mean reliability factors with Bayesian shrinkage (`prior_strength=8`) boost consistently-correct voters up to 2x and demote consistently-wrong ones down to 0.25x, renormalized to the base weight budget. With no resolved history it returns exactly the static defaults. |
| Historical-analog signal accuracy | `app/services/signal_accuracy.py` | Builds a discretized snapshot of the current bar (regime, structure, trend/RSI/ADX/ATR-percentile/range buckets, candle body) and scans the *same instrument's* history for the k most similar prior windows. Reports a Laplace-smoothed empirical up-probability, plus -- by walking each analog's forward path bar-by-bar against the candidate stop/target distances -- a measured **plan win probability** and expected value in R, with an evidence grade (STRONG/MODERATE/WEAK/INSUFFICIENT). Stop-first-inside-bar convention keeps estimates pessimistic rather than optimistic; no look-ahead (the current bar is never in its own analog set). |
| Adversarial debate agents | `app/services/debate_agents.py` | Bull agent vs bear agent vs judge: categorized evidence items (trend, momentum, volatility, structure, zones, divergence, patterns, levels) are collected from the existing tool stack, each side's case is scored with a cross-category diversity bonus, and the judge returns BUY/SELL/HOLD with margin, confidence, required conditions, and plain-English reasoning. `review_signal()` is the critic pass over any candidate: PASS / CAUTION / VETO (veto requires both strong contradiction *and* a weak supporting case, so no single dissenting tool can unilaterally kill a signal). |
| Session-time intelligence | `app/services/session_intelligence.py` | Classifies UTC time into Sydney/Tokyo/London/New-York sessions and their overlaps, computes this instrument's own per-hour true-range profile from recent bars, flags whether the current hour is historically hot or dead for this symbol, and applies a confidence multiplier that only ever damps (low-liquidity windows produce more false breaks and wider effective spreads). |
| Regime-shift + data-quality gating | `app/services/regime_shift.py` | Two-sided CUSUM structural-break detection on returns plus short/long realized-volatility ratio classification (ELEVATED/NORMAL/COMPRESSED), producing a trust multiplier that damps confidence after detected breaks (calibration data predates the new regime). The data-quality gate catches frozen feeds (runs of identical closes), stale timestamp gaps beyond 6x the median interval, extreme >12-sigma gap bars, and non-positive prices, returning OK/WARN/FAIL. |

### How they wire into signal generation

`confluence_orchestrator.run_symbol()` now layers these on top of the existing vote engine:

1. **Adaptive weights** replace `DEFAULT_VOTER_WEIGHTS` inside every timeframe's vote aggregation (falling back to static weights when the ledger has no resolved history).
2. After direction + calibrated stop/target are computed, the **adversarial critic** reviews the full plan geometry; VETO damps confidence by 35%, CAUTION by 15%.
3. The **regime-shift trust multiplier** and **session confidence multiplier** are applied (both <= 1.0), and a FAIL from the data-quality gate halves confidence.
4. Every layer's contribution is recorded in the persisted signal's `votes` metadata (`adaptive_weights`, `critic`, `regime_shift`, `session`, `data_quality`) so "why is this confidence what it is" stays fully auditable.

Each layer is individually failure-isolated: if any of them errors, the signal still generates with the remaining layers (rule R9).

### New endpoints

| Endpoint | Purpose |
| --- | --- |
| `GET /api/calibration/voter-weights?symbol=&strategy=` | Inspect learned voter weights, reliability factors, and how many resolved samples back them |
| `POST /api/analysis/signal-accuracy` | Historical-analog accuracy scoring for a candidate (or implied) plan: empirical up-probability, plan win probability, expected value in R, evidence grade |
| `POST /api/agents/debate` | Full bull-vs-bear adversarial debate with judge verdict and reasoning transcript |
| `POST /api/agents/signal-review` | Critic pass over a candidate signal: PASS / CAUTION / VETO with reasons |
| `POST /api/tools/session-intelligence` | Current session context, hourly volatility profile, execution notes |
| `POST /api/tools/regime-shift` | CUSUM break detection, volatility-state classification, data-quality gate |

The test suite covers every new service (21 unit/integration tests) including an orchestrator-level integration test asserting all five accuracy layers appear in generated signals' metadata and that ledger persistence continues to work unchanged.

## New indicator generation and pattern-mined original strategies (2026-08 revision 3)

Version 2.4 adds a third-generation indicator batch -- 15 composite oscillators and adaptive filters, bringing the registered catalog to 198: `CONNORS_RSI`, `LAGUERRE_RSI` (Ehlers recursive filter), `ZLEMA_DISTANCE`, `MCGINLEY_DISTANCE`, `VHF`, `CHANDE_FORECAST_OSC`, `QSTICK`, `INTRADAY_INTENSITY`, `CHAIKIN_OSC`, `KLINGER_OSC`, `WAVE_TREND`, `SQZ_MOMENTUM`, `ELDER_IMPULSE`, `GAPO`, and `PGO`. All are registry members, so they participate everywhere indicators do: rule validation, backtests, the confluence vote stack, and the mining engine below. (The 2026-08 revision-4 batch documented above extends the catalog to 208 and fixes a set of silent alias placeholders.)

### Pattern-mining strategy discovery (`app/services/strategy_miner.py`)

Instead of only hand-coding strategies, the repository now LEARNS ORIGINAL ones from an instrument's own history:

1. **Atomic condition grid** -- ~40 threshold conditions over registered indicators only (`RSI_14 < 35`, `MACD > 0`, quantile cuts for oscillators like `WAVE_TREND`). Atoms are stored as (indicator, operator, value) triples, so every mined config is immediately executable by `BacktestEngine` and passes rule validation.
2. **Forward-edge measurement** -- vectorized, no-look-ahead outcome arrays on completed bars (condition at bar i; outcome over i+1..i+horizon): hit-rate vs unconditional baseline, sample size.
3. **Out-of-sample gate** -- top atoms are combined pairwise (same-direction AND logic); every single/pair candidate must re-confirm its edge sign and magnitude on a strictly later validation slice (last 30% of bars). Survivors are ranked by an OOS-weighted score.
4. **Config synthesis** -- entry rules from winning atoms, mirror exit rules, ATR stop/target multiples, direction from edge sign, holding cap of 2x horizon.

### Mining sweep: XAUUSD + EURUSD x ALL 10 timeframes

`scripts/run_pattern_mining_backtests.py` runs the full loop per (symbol, timeframe): maximum-depth history load -> mine -> validate each mined config through the no-look-ahead engine on a recent window -> persist artifacts. It is checkpoint-resumable at group granularity and records OK/ERROR per unit (rule R9).

Latest committed run: **20/20 groups OK, 60 original strategies mined** (XAUUSD and EURUSD across 1m/5m/15m/30m/1h/2h/4h/8h/1d/1w), artifacts in `data/mined_strategies/`, audit trail in `reports/mined_strategies_raw.jsonl` + `reports/mining_progress.json`, human summary in `reports/mined_strategies_summary.md`.

> **Data-source disclosure (rule R8):** live Deriv history was unreachable from this sandbox (WebSocket upgrade header mangled by egress proxying -- same class of issue documented in `docs/backtest_data_findings.md`; Yahoo also failed). The sweep therefore ran on the deterministic demo source, explicitly recorded in every artifact with the fallback reason. Note the visible consequence in the summary: the demo generator is seeded per-symbol, so all timeframes of one symbol share one price path (identical scores within a symbol). Re-run `python3 scripts/run_pattern_mining_backtests.py --source deriv` wherever real market data is reachable to produce timeframe-distinct learned patterns under rule R3.

| Endpoint | Purpose |
| --- | --- |
| `GET /api/mined-strategies?symbol=XAUUSD` | Review pattern-mined strategies per symbol with their train/validation evidence and engine-validation metrics |

Run it yourself:

```bash
python3 scripts/run_pattern_mining_backtests.py                       # XAUUSD + EURUSD x all timeframes
python3 scripts/run_pattern_mining_backtests.py --source deriv        # force real-data mode
python3 scripts/run_pattern_mining_backtests.py --symbols XAUUSD --timeframes 1h,4h
```

## MetaTrader 5 real-time data integration (2026-08 revision 4)

The bot now connects to a locally installed, running MetaTrader 5 terminal through the official `MetaTrader5` Python package (`app/services/mt5_client.py`) and documents the companion MCP bridge (`ariadng/metatrader-mcp-server`, SSE at `http://127.0.0.1:8080/sse`) used for agent tooling. MT5 supplies **real-time forex/metal data**; Deriv's public API remains the source for synthetic indices (Volatility / Drift Switch), which local brokers do not carry.

| Endpoint | Purpose |
| --- | --- |
| `GET /api/mt5/status` | Terminal connection diagnostics + bridge URL + retry policy |
| `GET /api/mt5/symbols` | Every symbol the connected broker serves |
| `GET /api/mt5/ohlc?symbol=EURUSD&bars=200&interval=1h` | Real OHLC bars from the terminal |
| `GET /api/mt5/price?symbol=XAUUSD` | Latest bid tick |
| `HistoricalDataProvider.load(..., source="mt5")` | MT5-backed bars for backtests and analysis |

The integration is hard-gated to real data only (rule R3): transient failures are retried (`MT5_FETCH_RETRIES`, default 3) and then surface an error -- there is no demo/synthetic fallback anywhere in the path. See `docs/mt5_integration.md`.

## Fourth-generation indicators: proper implementations replacing silent placeholders (2026-08 revision 4)

An audit found that a set of registered indicator names silently returned *unrelated generic values* through alias fall-throughs -- e.g. `VORTEX_PLUS`, `DX`, `EASE_OF_MOVEMENT`, `STC`, and `DPO` all returned a plain SMA. Every affected name now has its proper published implementation:

- **Fixed:** `VORTEX_PLUS`/`VORTEX_MINUS`, `DX`, `EASE_OF_MOVEMENT` (volume-normalized), `STC` (Schaff Trend Cycle), `KAMA_20` (real efficiency-ratio recursion), `TSI`, `RVI`, `DPO`, `BOP`, `NVI`, `STOCH_RSI`, plus corrected `NATR` (percent scale), `TRANGE` (true range), and legacy aliases for `FISHER`/`CHOPPINESS`/`COPPOCK`.
- **New (catalog now 208):** `SMI_ERGODIC`, `CG_OSCILLATOR` (Ehlers Center of Gravity), `FRAMA_DISTANCE` (Ehlers' original fractal-adaptive formulation), `PSYCHOLOGICAL_LINE_14`, `DISPARITY_INDEX_20`, `ELDER_THERMOMETER`, `WAD`, `CHANDE_KROLL_LONG`/`CHANDE_KROLL_SHORT`, and `RMI_14`.
- **Deriv client retries:** `_fetch_candles` now retries rate-limit and transient empty-candle responses with backoff+jitter before raising (rule R3: retry until available, never substitute simulated data).

### Twelve new fourth-generation strategies

`builtin_strategies()` grows to 62 templates (+4 `ADVANCED_BUILTIN_STRATEGIES` = 66 total): TSI Momentum Ignition, Vortex+DX Trend Start, Schaff Cycle Swing, RMI Trend Pullback, Psychological Line Extreme, Disparity Extension Fade, Thermometer Breakout, Chande Kroll Band Breakout, FRAMA Adaptive Follow, SMI+CG Dual Oscillator, StochRSI Oversold Double, EOM Volume Surge -- each parametrized-tested end-to-end through the no-look-ahead backtester, alongside two new agent-stack templates (`schaff_vortex_regime_guard`, `frama_trend_agent_stack`).
