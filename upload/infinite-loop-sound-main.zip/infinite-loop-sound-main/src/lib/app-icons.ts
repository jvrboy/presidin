export interface AppIcon {
  id: string;
  name: string;
  path: string;
  colors: { bg: string; fg: string; accent: string };
}

export const APP_ICONS: AppIcon[] = [
  {
    id: "default",
    name: "Divergence",
    path: "/app-icons/default.svg",
    colors: { bg: "#0a0e1a", fg: "#3b82f6", accent: "#60a5fa" },
  },
  {
    id: "aurora",
    name: "Aurora",
    path: "/app-icons/aurora.svg",
    colors: { bg: "#0c2340", fg: "#2dd4bf", accent: "#67e8f9" },
  },
  {
    id: "amber",
    name: "Trader Amber",
    path: "/app-icons/amber.svg",
    colors: { bg: "#1f1408", fg: "#f59e0b", accent: "#fbbf24" },
  },
  {
    id: "neon",
    name: "Neon Cyber",
    path: "/app-icons/neon.svg",
    colors: { bg: "#1a0833", fg: "#ec4899", accent: "#a855f7" },
  },
  {
    id: "matrix",
    name: "Matrix",
    path: "/app-icons/matrix.svg",
    colors: { bg: "#001a00", fg: "#22c55e", accent: "#4ade80" },
  },
  {
    id: "crimson",
    name: "Crimson",
    path: "/app-icons/crimson.svg",
    colors: { bg: "#1a0008", fg: "#ef4444", accent: "#f87171" },
  },
  {
    id: "arctic",
    name: "Arctic",
    path: "/app-icons/arctic.svg",
    colors: { bg: "#001428", fg: "#38bdf8", accent: "#7dd3fc" },
  },
  {
    id: "void",
    name: "Void",
    path: "/app-icons/void.svg",
    colors: { bg: "#000000", fg: "#6b7280", accent: "#9ca3af" },
  },
  {
    id: "ocean",
    name: "Ocean",
    path: "/app-icons/ocean.svg",
    colors: { bg: "#0c4a6e", fg: "#0ea5e9", accent: "#38bdf8" },
  },
  {
    id: "forest",
    name: "Forest",
    path: "/app-icons/forest.svg",
    colors: { bg: "#052e16", fg: "#16a34a", accent: "#4ade80" },
  },
  {
    id: "sunset",
    name: "Sunset",
    path: "/app-icons/sunset.svg",
    colors: { bg: "#1a0a00", fg: "#f97316", accent: "#fb923c" },
  },
  {
    id: "royal",
    name: "Royal",
    path: "/app-icons/royal.svg",
    colors: { bg: "#1a1a2e", fg: "#6366f1", accent: "#818cf8" },
  },
  {
    id: "gold",
    name: "Gold",
    path: "/app-icons/gold.svg",
    colors: { bg: "#1c1917", fg: "#eab308", accent: "#facc15" },
  },
  {
    id: "teal",
    name: "Teal",
    path: "/app-icons/teal.svg",
    colors: { bg: "#042f2e", fg: "#14b8a6", accent: "#2dd4bf" },
  },
  {
    id: "rose",
    name: "Rose",
    path: "/app-icons/rose.svg",
    colors: { bg: "#1a0a10", fg: "#f43f5e", accent: "#fb7185" },
  },
  {
    id: "slate",
    name: "Slate",
    path: "/app-icons/slate.svg",
    colors: { bg: "#1e293b", fg: "#94a3b8", accent: "#cbd5e1" },
  },
  {
    id: "emerald",
    name: "Emerald",
    path: "/app-icons/emerald.svg",
    colors: { bg: "#022c22", fg: "#10b981", accent: "#34d399" },
  },
];

const STORAGE_KEY = "diq.appIcon";

export function getActiveIcon(): string {
  if (typeof localStorage === "undefined") return "default";
  return localStorage.getItem(STORAGE_KEY) || "default";
}

export function setActiveIcon(iconId: string): void {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(STORAGE_KEY, iconId);
  window.dispatchEvent(new CustomEvent("diq:icon-change", { detail: iconId }));
}

export default APP_ICONS;
